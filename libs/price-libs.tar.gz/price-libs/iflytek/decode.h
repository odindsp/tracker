#ifndef DECODE_INMOBI_H_
#define DECODE_INMOBI_H_

#include "../type.h"

extern "C"
{
int DecodeWinningPrice(char *encodedprice, double *value);
}
#endif
