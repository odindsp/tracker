#ifndef DECODE_BAIDU_VIDEOS_H_
#define DECODE_BAIDU_VIDEOS_H_

#include "../type.h"

extern "C"
{
int DecodeWinningPrice(char *encodedprice, double *value);
}
#endif
