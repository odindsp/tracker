#ifndef DECODE_IWIFI_H_
#define DECODE_IWIFI_H_

extern "C"
{
    int DecodeWinningPrice(char *encodedprice, double *value);
}
#endif
